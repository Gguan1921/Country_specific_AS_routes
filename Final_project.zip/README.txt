All country name are in ISO Alpha-2


USAGE:

*********paths_finder.py*********

To use local data from previous query:

$python paths_finder.py country -local

To query new data for a country:

$python paths_finder.py country


*********paht_ana.py*********

To find all unique paths between pairs:

$python paths_ana.py country